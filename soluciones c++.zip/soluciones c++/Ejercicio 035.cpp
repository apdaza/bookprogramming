#include <iostream>
using namespace std;

int main(){
	int x = 1;
	while(x<=100){
		if(x%5==0){
			cout << x << endl;
		}
		x++;
	}
	return 0;
}
