#include <iostream>
using namespace std;

int main(){
	int n;
	cout << "Ingrese el valor de n: ";
	cin >> n;
	if(n>=0){
		cout << "el numero leido es positivo " << endl;	
	}else{
		cout << "el numero leido es negativo " << endl;		
	}
	return 0;
}
