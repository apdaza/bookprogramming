#include <iostream>
using namespace std;

int main(){
	string nombre;
	cout << "Buen dia, ingrese su nombre:" << endl;
	cin >> nombre;
	cout << "Bienvenido " << nombre << endl;
	return 0;
}
