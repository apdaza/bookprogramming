#include <iostream>
using namespace std;

int main(){
	int a,b;
	cout << "Ingrese el primer numero: ";
	cin >> a;
	cout << "Ingrese el segundo numero: ";
	cin >> b;
	cout << "la suma de " << a << " + " << b << " es " << a+b << endl;
	cout << "la resta de " << a << " - " << b << " es " << a-b << endl;
	cout << "el producto de " << a << " * " << b << " es " << a*b << endl;
	cout << "la division de " << a << " / " << b << " es " << a/b << endl;
	return 0;
}
